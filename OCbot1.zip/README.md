# OCbot1 — Gyaru Tomboy Discord Bot

This repository contains OCbot1: a gyaru-style tomboy anime chatbot that replies to `!chat` commands,
uses OpenRouter for AI responses, keeps **shared memory** (server-wide), and attaches an emotion image
(happy/sad/angry/neutral) to each reply.

## Files
- `index.js` — Bot code (Node.js, discord.js)
- `package.json` — npm dependencies
- `memory.json` — shared memory file (auto-updated)
- `images/` — emotion PNGs: `happy.png`, `sad.png`, `angry.png`, `neutral.png`

## Deploy (Render)
1. Create a GitHub repo and upload these files (or use the ZIP).
2. Sign up at https://render.com and connect your GitHub.
3. Create a **Web Service**, choose the repo.
4. Set:
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Choose Node 18+
5. Add environment variables on Render:
   - `DISCORD_TOKEN` = your Discord bot token
   - `OPENROUTER_API_KEY` = your OpenRouter API key
6. Deploy. Render will keep the bot running.

## Notes
- Trigger: `!chat` at the start of a message (e.g., `!chat Hey OCbot1!`).
- Shared memory keeps recent messages (helpful for continuity). If you want per-user memory, edit the memory storage logic in `index.js`.
- Replace the placeholder images with higher-quality anime art if you want; keep the filenames the same.

Enjoy OCbot1! 💖